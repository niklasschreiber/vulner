# gorm-outside-grails

[Using GORM for Hibernate Outside Grails](http://gorm.grails.org/latest/hibernate/manual/index.html#outsideGrails) example.
