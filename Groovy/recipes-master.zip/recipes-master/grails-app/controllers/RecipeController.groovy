import com.recipes.Recipe

class RecipeController {
    def scaffold = Recipe.class
}

