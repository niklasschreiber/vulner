constraints = {
	title(blank:false)
	description(blank:false)
	date(nullable:false)
}