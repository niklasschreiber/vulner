package graphql.demo.simple

enum PetType {
    DOG,
    CAT,
    FISH,
    GERBIL,
    SNAKE,
    EXOTIC
}
