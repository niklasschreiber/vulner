import graphql.demo.MyGraphQLPostProcessor

// Place your Spring DSL code here

beans = {

    myGraphQLPostProcessor(MyGraphQLPostProcessor)
}
