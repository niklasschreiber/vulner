package graphql.demo.simple

class Pet {

    String name
    PetType type

    static constraints = {
    }

    static graphql = true
}
