package graphql.demo

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
