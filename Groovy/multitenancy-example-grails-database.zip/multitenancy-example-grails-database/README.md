# Example of Grails Multitenancy 

![Master branch - Travis badge](https://travis-ci.org/grails-samples/multitenancy-example-grails.svg?branch=master)
![geb-1.1.1 - Travis badge](https://travis-ci.org/grails-samples/multitenancy-example-grails.svg?branch=geb-1.1.1)

This sample shows how to integrate Multitenancy in the sample app [Geb example application](https://github.com/grails-samples/geb-example-grails])