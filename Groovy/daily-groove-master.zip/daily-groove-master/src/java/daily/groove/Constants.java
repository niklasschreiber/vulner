package daily.groove;

public interface Constants {
    String SAMPLE_FEEDS_KEY = "sampleFeeds";
    String SUBSCRIBED_FEEDS_KEY = "subscribedFeeds";
}
