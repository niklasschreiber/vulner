package demo

class Car {

    String name

    static constraints = {
    }
}
