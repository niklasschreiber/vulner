package demo

class Book {

    String title

    static mapping = {
        datasource 'books'
    }
}
