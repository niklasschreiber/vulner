package evil

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
