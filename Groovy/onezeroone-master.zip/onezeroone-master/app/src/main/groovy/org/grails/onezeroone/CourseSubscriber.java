package org.grails.onezeroone;

public interface CourseSubscriber {
    String getEmail();
    SubscriptionDay getSubscriptionDay();
}
