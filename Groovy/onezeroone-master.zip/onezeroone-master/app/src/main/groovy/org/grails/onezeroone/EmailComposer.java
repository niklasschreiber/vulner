package org.grails.onezeroone;

public interface EmailComposer {
    Email compose(SubscriptionDay day);
}
