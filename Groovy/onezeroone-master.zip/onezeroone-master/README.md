# Grails 101

[Documentation](https://grails-onezeroone.github.io/grails-slack/snapshot/)
 

## Plugins Used

[Grails schwartz Plugin](https://github.com/agileorbit/grails-schwartz)