class Person implements java.io.Serializable {  
	String name       
	
	static constraints = {
		name(blank:false)
	}
}	
