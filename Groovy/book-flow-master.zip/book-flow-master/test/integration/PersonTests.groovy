class PersonTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
