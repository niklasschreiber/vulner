package demo

class Book {
    String title
}