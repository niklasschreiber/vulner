Edit `src/main/resources/application.properties`. Configure your database and username.

Run the app with `./gradlew bootRun`

See [GORM for Hibernate Docs](http://gorm.grails.org/7.0.0.RC1/hibernate/manual/index.html#dataServices).