package hello.heroku

class ProductController {
    static scaffold = true
}
