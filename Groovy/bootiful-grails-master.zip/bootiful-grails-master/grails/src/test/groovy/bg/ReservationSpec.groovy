package bg

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class ReservationSpec extends Specification implements DomainUnitTest<Reservation> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
