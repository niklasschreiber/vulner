# bootiful-grails
Spring Boot And Grails Demonstrations 2017
