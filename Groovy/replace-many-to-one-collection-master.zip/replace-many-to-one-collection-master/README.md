# GORM replace many-to-one collection

GORM, a powerful Groovy-based data access toolkit for the JVM, enables to create many-to-one relationships with ease. This repository shows how to replace a many collection in an efficient way by using a minimal number of queries. 
