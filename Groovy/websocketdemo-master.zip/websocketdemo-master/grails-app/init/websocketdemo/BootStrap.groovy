package websocketdemo

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
