# Groovy Succinctly

This is the companion repo for [*Groovy Succinctly*](https://www.syncfusion.com/ebooks/groovy_succinctly) by Duncan Dickinson. Published by Syncfusion.

## Pre-requisites

The code was prepared for use with Groovy 2.4.5 and the Java 8 JDK.

[![cover](https://github.com/SyncfusionSuccinctlyE-Books/Groovy-Succinctly/blob/master/cover.png)](https://www.syncfusion.com/ebooks/groovy_succinctly)

## Looking for more _Succinctly_ titles?

Check out the entire library of more than 130 _Succinctly_ e-books at [https://www.syncfusion.com/ebooks](https://www.syncfusion.com/ebooks).


