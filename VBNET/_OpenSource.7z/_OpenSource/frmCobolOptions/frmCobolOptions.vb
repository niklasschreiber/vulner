﻿Imports CommonParts
Imports System.Reflection
Imports System.Reflection.Emit
Imports System.Xml
Imports System.IO

Public Class frmCobolOptions

    Dim dsSettings As New DataSet
    Dim _program As Assembly = AssemblyBuilder.GetExecutingAssembly()       'Name Program
    Dim _assemblyName As AssemblyName = _program.GetName()                  'Name Assemnbly

    Private _rTextBox As New TextBox
    Public Property rTextBox As TextBox
        Get
            rTextBox = _rTextBox
        End Get
        Set(ByVal value As TextBox)
            _rTextBox = value
        End Set
    End Property


    Private _StatementsLength As Integer
    Public Property StatementsLength As Integer
        Get
            StatementsLength = _StatementsLength
        End Get
        Set(ByVal value As Integer)
            _StatementsLength = value
        End Set
    End Property

    Private _FolderCopy As String
    Public Property FolderCopy As String
        Get
            FolderCopy = _FolderCopy
        End Get
        Set(ByVal value As String)
            _FolderCopy = value
        End Set
    End Property

    Private Sub tsClose_Click(sender As Object, e As EventArgs) Handles tsClose.Click
        Me.Close()
    End Sub

    Private Sub frmCobolOptions_Load(sender As Object, e As EventArgs) Handles Me.Load

        Dim nameMethod = Me.GetType().Name
        Dim st As StackTrace = New StackTrace()
        Dim sf As StackFrame = st.GetFrame(0) 'current method
        Dim xmlDatadoc As XmlDocument = New XmlDocument()

        Try
            If Not IO.File.Exists(CommonPartsReviewer.PathSettings) Then
                MsgBox("The File Settings.sr was not found", MsgBoxStyle.Critical, "Cobol Options")
                CommonPartsReviewer.Logger("The File Settings.sr was not found", EventLogEntryType.Information, _assemblyName.Name & "." & nameMethod & "." & sf.GetMethod().Name, rTextBox, False)
                Close()
            End If

            If Not CommonPartsReviewer.CalculateRulesRules(CommonPartsReviewer.PathSettings, xmlDatadoc, dsSettings) Then
                Close()
            Else

                Dim SettingsCobol = dsSettings.Tables("ListSettings").Select().Where(Function(k) k.Item("Language") = "Cobol")

                For Each itemCobol In SettingsCobol
                    If itemCobol.Item("StatementsLength") = 88 Then opt88.Checked = True Else opt122.Checked = True
                    txtFolderCopy.Text = itemCobol.Item("FolderCopy")
                Next

            End If

        Catch ex As Exception
            CommonPartsReviewer.Logger(Err.Description, EventLogEntryType.Information, _assemblyName.Name & "." & nameMethod & "." & sf.GetMethod().Name, rTextBox)
        End Try


    End Sub


    Private Sub tsSave_Click(sender As Object, e As EventArgs) Handles tsSave.Click

        Dim nameMethod = Me.GetType().Name
        Dim st As StackTrace = New StackTrace()
        Dim sf As StackFrame = st.GetFrame(0) 'current method

        Try

            If opt88.Checked Then
                dsSettings.Tables("ListSettings").Rows(0).Item("StatementsLength") = 88
            Else
                dsSettings.Tables("ListSettings").Rows(0).Item("StatementsLength") = 122
            End If


            dsSettings.Tables("ListSettings").Rows(0).Item("FolderCopy") = txtFolderCopy.Text

            dsSettings.AcceptChanges()
            dsSettings.WriteXml(IO.Path.GetTempPath & "\Settings.tmp")

            If CommonPartsReviewer.EncryptFile(IO.Path.GetTempPath & "\Settings.tmp", CommonPartsReviewer.PathSettings) = False Then
                CommonPartsReviewer.Logger(Err.Description, EventLogEntryType.Information, _assemblyName.Name & "." & nameMethod & "." & sf.GetMethod().Name, rTextBox)
                MsgBox("Config Settings Saved Successfully", MsgBoxStyle.Information, "Cobol Options")
                dsSettings.RejectChanges()
                Exit Sub
            End If

            IO.File.Delete(IO.Path.GetTempPath & "\Settings.tmp")
            MsgBox("Config Settings Saved Successfully", MsgBoxStyle.Information, "Cobol Options")

        Catch eIO As IOException
            CommonPartsReviewer.Logger(Err.Description, EventLogEntryType.Information, _assemblyName.Name & "." & nameMethod & "." & sf.GetMethod().Name, rTextBox)
            MsgBox(Err.Description, MsgBoxStyle.Critical, _assemblyName.Name & "." & nameMethod & "." & sf.GetMethod().Name)

        Catch ex As Exception
            CommonPartsReviewer.Logger(Err.Description, EventLogEntryType.Information, _assemblyName.Name & "." & nameMethod & "." & sf.GetMethod().Name, rTextBox)
            MsgBox("Config Settings Saved Unsuccessfully", MsgBoxStyle.Information, "Cobol Options")
            dsSettings.RejectChanges()
        End Try
    End Sub

   
    Private Sub pbChangeFoldeCopy_Click(sender As Object, e As EventArgs) Handles pbChangeFoldeCopy.Click

        FolderBrowserCopy.ShowDialog()
        If FolderBrowserCopy.SelectedPath <> String.Empty Then
            txtFolderCopy.Text = FolderBrowserCopy.SelectedPath
        End If

    End Sub
End Class