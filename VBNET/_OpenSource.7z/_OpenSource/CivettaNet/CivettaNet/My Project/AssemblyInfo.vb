﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Le informazioni generali relative a un assembly sono controllate dal seguente 
' set di attributi. Modificare i valori di questi attributi per modificare le informazioni
' associate a un assembly.

' Rivedere i valori degli attributi dell'assembly
<Assembly: AssemblyTitle("CivettaNet")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("CivettaNet")> 
<Assembly: AssemblyCopyright("Copyright ©  2013")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'Se il progetto viene esposto a COM, il GUID seguente verrà utilizzato per creare l'ID della libreria dei tipi
<Assembly: Guid("07f1a94b-9db8-44e5-a756-ce6a5678de47")> 

' Le informazioni sulla versione di un assembly sono costituite dai quattro valori seguenti:
'
'      Versione principale
'      Versione secondaria 
'      Numero build
'      Revisione
'
' È possibile specificare tutti i valori oppure impostare come predefiniti i valori Numero revisione e Numero build 
' utilizzando l'asterisco (*) come illustrato di seguito:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
